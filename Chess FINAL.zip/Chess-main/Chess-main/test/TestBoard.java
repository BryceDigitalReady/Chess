import org.junit.Test;

import static java.awt.Color.BLACK;
import static org.junit.Assert.*;

public class TestBoard {
    @Test
    public void testBoard() {
        Board[][] board = new Board[0][8];
        assertNotNull(board);

    }
}

 
