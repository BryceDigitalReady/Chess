public class ChessColor {
}
